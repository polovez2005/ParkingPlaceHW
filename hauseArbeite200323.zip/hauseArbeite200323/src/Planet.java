import javax.xml.namespace.QName;

public class Planet {
    public int numberOfMoons;
    String name;

    Planet() {
        printOfDruck(this.numberOfMoons, this.name);
    }

    Planet(int numberOfMoons) {
        this.numberOfMoons = numberOfMoons;
        printOfDruck(this.numberOfMoons, this.name);

    }

    Planet(String name) {
        this.name = name;
        System.out.println("Ich bin Planete " + this.name);
        printOfDruck(this.numberOfMoons, this.name);

    }

    Planet(String name, int numberOfMoons) {
        this.name = name;
        this.numberOfMoons = numberOfMoons;
        printOfDruck(this.numberOfMoons, this.name);


    }

    static void printOfDruck(int numberOfMoons, String name){
        System.out.println("Name - " + name);
        System.out.println("Summe Satelite: " + numberOfMoons);
        System.out.println();
    }

}