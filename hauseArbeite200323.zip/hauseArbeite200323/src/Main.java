public class Main {
    public static void main(String[] args) {

        Planet venera = new Planet();
        Planet erde = new Planet("Erde" , 1);
       Planet mars = new Planet(2);
       Planet saturn = new Planet("Saturn");
       Planet jupiter = new Planet("Jupiter " ,79);



    }
}